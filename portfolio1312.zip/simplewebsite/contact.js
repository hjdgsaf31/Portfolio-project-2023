const name=document.getElementById("name");
const email=document.getElementById("email");
const mobile=document.getElementById("mobile");
const message=document.getElementById("message");
const submit=document.getElementsByClassName("form-contact")[0];

submit.addEventListener('submit', (e)=>{
    e.preventDefault();
    console.log("Clicked");

    





    Email.send({
        SecureToken : "550dcb93-202a-44cc-adbe-c1a57927d5cb",
        To : 'armsteong21344@gmail.com',
        From : "armsteong21344@gmail.com",
        Subject : "Testing email",
        Body : "Test by lewis"
    }).then(
      message => alert(message)
    ); 






})
