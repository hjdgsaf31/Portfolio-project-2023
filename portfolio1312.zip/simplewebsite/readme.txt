//please open the index.html file 
//secondly to open and check the website please right click and click  the live server and the website will be displaying 
//this will display on the website