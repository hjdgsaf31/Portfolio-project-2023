function show_result(){
  let math= document.querySelector("#math").value;
  let e = document.querySelector("#e").value
  let s = document.querySelector("#s").value
  let c = document.querySelector("#c").value;

  let to = parseFloat(math) + parseFloat(e)+parseFloat(s)+parseFloat(c);
  let percent = (to*100)/400;

  if(percent>=90){
    document.querySelector(".gra").innerHTML="A*";
  }else if(percent>=80){
    document.querySelector(".gra").innerHTML="A";
  }else if (percent>=70){
    document.querySelector(".gra").innerHTML="B";
  }else if(percent<=70){
    document.querySelector(".gra").innerHTML="C";
  }else if(percent<=40){
    document.querySelector(".gra").innerHTML="D"
  }else{
    document.querySelector(".gra").innerHTML="You have failed";
  }

  document.querySelector(".to").innerHTML =to;
  document.querySelector(".percent").innerHTML=percent;

  if(percent>30){
    document.querySelector(".result h2").innerHTML ="You have  achieved Pass"
  }else if (percent>50){
    document.querySelector(".result h2").innerHTML="You have achieved Merit "
  }
  
  else{
    document.querySelector(".result h2").innerHTML="You have failed";
  }
  

}