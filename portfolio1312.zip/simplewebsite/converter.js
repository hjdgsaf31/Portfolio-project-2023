let button = document.getElementById('btn');

button.addEventListener('click',function(){
    const Meter = parseInt(document.getElementById('Meters').value);
    const type = document.getElementById('type').value;

 
   

    
    
    
    if(Meter == ''|| isNaN(Meter)){
        document.getElementById('Meters').focus();
        document.getElementById('error').innerHTML ='Please provide a valid meter';
        document.getElementById('output').innerHTML='';
    }else{
        document.getElementById('error').innerHTML='';
        switch(type){
           case 'Centimeter':
            convert_Centimeter(Meter);
            break;
            case 'Kilometer':
             convert_Kilometer(Meter);
             break;
             case 'Millimeter':
              convert_Millimeter(Meter);
              break;
             case 'Miles':
              convert_Miles(Meter);
              break;
              default:
                  alert('error');

        }

        function convert_Centimeter(meter){
            let rate = 100, Centimeter;
            Centimeter = meter*rate;
            document.getElementById('Output').innerHTML =meter + "Meters = " + Centimeter.toFixed(3)+'Centimeter.'
        }
        function convert_Kilometer(meter){
            let rate = 1000, Kilometer;
            Kilometer = meter/rate;
            document.getElementById('Output').innerHTML= meter + "Meters =" + Kilometer.toFixed(3)+'Kilometer.'    
        }
        function convert_Millimeter(meter){
            let rate = 1000,Millimeter;
            Millimeter = meter*rate;
            document.getElementById('Output').innerHTMl = meter +"Meters ="+ Millimeter.toFixed(3)+'Millimeter.'
        }
        function convert_Miles(meter){
            let rate = 0.00621,Miles;
            Miles= meter*rate; 
            document.getElementById('Output').innerHTML = meter + "Meters = " + Miles.toFixed(3)+'Miles'
        }
    }
})

